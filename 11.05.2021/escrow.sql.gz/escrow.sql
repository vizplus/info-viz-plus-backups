-- MariaDB dump 10.17  Distrib 10.4.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: info_vizplus
-- ------------------------------------------------------
-- Server version	10.4.8-MariaDB-1:10.4.8+maria~stretch-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `escrow`
--

DROP TABLE IF EXISTS `escrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `escrow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `escrow_id` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `agent` int(11) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `fee` bigint(20) NOT NULL,
  `json` longtext NOT NULL,
  `time` int(11) NOT NULL,
  `ratification_deadline` int(11) NOT NULL,
  `expiration` int(11) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `approved_by_to` tinyint(1) NOT NULL DEFAULT 0,
  `approved_by_agent` tinyint(1) NOT NULL DEFAULT 0,
  `dispute` tinyint(1) NOT NULL DEFAULT 0,
  `dispute_by` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `expired` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `active_escrow_id_from` (`active`,`escrow_id`,`from`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrow`
--

LOCK TABLES `escrow` WRITE;
/*!40000 ALTER TABLE `escrow` DISABLE KEYS */;
INSERT INTO `escrow` VALUES (1,30,604,3330,3143,0,0,'\"{\\\"mess\\\": \\\"Hello Wordl!\\\"}\"',1559940762,1559942514,1559947914,0,0,0,0,0,0,1),(2,1,6,1,4,0,0,'\"{}\"',1571378943,1571465345,1571551745,0,0,0,0,0,0,1),(3,1,6,1,0,0,0,'\"{\\\"description\\\":\\\"test escrow time freeze\\\"}\"',1573318644,1573577845,1573837045,0,0,0,0,0,0,1),(4,1,6,1,0,0,0,'\"{\\\"description\\\":\\\"test\\\"}\"',1577446023,1577446080,1577446081,0,0,0,0,0,0,1),(5,1,6,1,0,0,0,'\"{\\\"description\\\":\\\"test2\\\"}\"',1577446158,1577446200,1577446201,0,0,0,0,0,0,1),(6,1,6,1,0,0,0,'\"{\\\"description\\\":\\\"first time, start\\\"}\"',1577447259,1601337600,1601337601,0,0,0,0,0,0,1),(7,2,6,1,0,2000000000,0,'\"{\\\"description\\\":\\\"second time\\\"}\"',1577447277,1632873600,1632873601,0,0,0,0,0,1,0),(8,3,6,1,0,3000000000,0,'\"{\\\"description\\\":\\\"third time\\\"}\"',1577447292,1664409600,1664409601,0,0,0,0,0,1,0),(9,4,6,1,0,4000000000,0,'\"{\\\"description\\\":\\\"fourth time\\\"}\"',1577447301,1695945600,1695945601,0,0,0,0,0,1,0),(10,5,6,1,0,5000000000,0,'\"{\\\"description\\\":\\\"fifth time\\\"}\"',1577447307,1727568000,1727568001,0,0,0,0,0,1,0),(11,6,6,1,0,6000000000,0,'\"{\\\"description\\\":\\\"sixth time\\\"}\"',1577447310,1759104000,1759104001,0,0,0,0,0,1,0),(12,7,6,1,0,7000000000,0,'\"{\\\"description\\\":\\\"seventh time, final\\\"}\"',1577447316,1790640000,1790640001,0,0,0,0,0,1,0),(13,1,7,1,0,0,0,'\"{\\\"description\\\":\\\"first time, start\\\"}\"',1577449935,1609200000,1609200001,0,0,0,0,0,0,1),(14,2,7,1,0,300000000,0,'\"{\\\"description\\\":\\\"second time\\\"}\"',1577450127,1640736000,1640736001,0,0,0,0,0,1,0),(15,3,7,1,0,400000000,0,'\"{\\\"description\\\":\\\"third time\\\"}\"',1577450142,1672272000,1672272001,0,0,0,0,0,1,0),(16,4,7,1,0,600000000,0,'\"{\\\"description\\\":\\\"fourth time\\\"}\"',1577450205,1703808000,1703808001,0,0,0,0,0,1,0),(17,5,7,1,0,1000000000,0,'\"{\\\"description\\\":\\\"fifth time\\\"}\"',1577450220,1735430400,1735430401,0,0,0,0,0,1,0),(18,6,7,1,0,1500000000,0,'\"{\\\"description\\\":\\\"sixth time, final\\\"}\"',1577450262,1766966400,1766966401,0,0,0,0,0,1,0),(19,1,3114,6,3397,0,0,'\"{\\\"description\\\":\\\"test escrow\\\"}\"',1585118322,1585204728,1585291128,1,1,1,0,0,0,1);
/*!40000 ALTER TABLE `escrow` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-10 23:03:31
