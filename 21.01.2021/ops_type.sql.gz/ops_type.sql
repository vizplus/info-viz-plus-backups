-- MariaDB dump 10.17  Distrib 10.4.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: info_vizplus
-- ------------------------------------------------------
-- Server version	10.4.8-MariaDB-1:10.4.8+maria~stretch-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ops_type`
--

DROP TABLE IF EXISTS `ops_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ops_type` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `d_count` int(11) NOT NULL,
  `w_count` int(11) NOT NULL,
  `m_count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ops_type`
--

LOCK TABLES `ops_type` WRITE;
/*!40000 ALTER TABLE `ops_type` DISABLE KEYS */;
INSERT INTO `ops_type` VALUES (1,'witness_reward',24316220,-548801,-377410,273265),(2,'witness_update',1592,-246,-237,-90),(3,'account_witness_vote',1768,-228,-255,-169),(4,'withdraw_vesting',3105,-113,-84,38),(5,'account_create',4434,-193,-105,-76),(6,'shutdown_witness',1000,-138,-134,107),(7,'transfer',91005,-1241,-899,775),(8,'delegate_vesting_shares',6192,-37,-23,185),(9,'content',137225,0,0,0),(10,'vote',8959,0,0,0),(11,'chain_properties_update',242,0,0,0),(12,'account_update',5009,-98,-72,-90),(13,'custom',2732117,539015,539136,545826),(14,'committee_worker_create_request',1913,-18,-12,-12),(15,'curation_reward',6554,0,0,0),(16,'author_reward',1498,0,0,0),(17,'content_reward',1498,0,0,0),(18,'content_payout_update',136365,0,0,0),(19,'fill_vesting_withdraw',17467,-87,68,577),(20,'content_benefactor_reward',1619,0,0,0),(21,'transfer_to_vesting',33945,-60,476,3462),(22,'committee_vote_request',1237,-203,-203,-29),(23,'committee_worker_cancel_request',12,0,1,0),(24,'create_invite',681,-23,-23,-19),(25,'hardfork',9,0,0,0),(26,'invite_registration',132,-16,-14,-22),(27,'committee_cancel_request',3711,-2,-3,-2),(28,'account_metadata',58615,37,58,96),(29,'set_withdraw_vesting_route',32,-10,-8,-11),(30,'claim_invite_balance',145,-4,-2,-4),(31,'return_vesting_delegation',4782,-25,-6,146),(32,'committee_approve_request',49,-2,-2,0),(33,'committee_pay_request',53,-1,-1,1),(34,'committee_payout_request',49,-1,-1,1),(35,'delete_content',11,0,0,0),(36,'account_witness_proxy',17,0,0,0),(37,'award',671947,1579,9447,37950),(38,'receive_award',580588,1430,8317,34450),(39,'versioned_chain_properties_update',390,0,0,2),(40,'benefactor_award',328861,366,1680,6228),(41,'set_paid_subscription',424,0,0,0),(42,'paid_subscribe',140,0,0,3),(43,'paid_subscription_action',839,0,9,41),(44,'cancel_paid_subscription',95,0,0,3),(45,'set_subaccount_price',32,0,0,0),(46,'set_account_price',832758,-619168,-619148,-619126),(47,'buy_account',31,0,0,0),(48,'account_sale',31,0,0,0),(49,'escrow_transfer',19,0,0,0),(50,'change_recovery_account',5,0,0,0),(51,'proposal_create',9,0,0,2),(52,'proposal_update',6,0,0,0),(53,'escrow_approve',2,0,0,0),(54,'escrow_release',5,0,0,0),(55,'escrow_dispute',1,0,0,0),(56,'use_invite_balance',236,0,0,0),(57,'expire_escrow_ratification',2,0,0,1);
/*!40000 ALTER TABLE `ops_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-21  0:12:10
