-- MariaDB dump 10.17  Distrib 10.4.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: info_vizplus
-- ------------------------------------------------------
-- Server version	10.4.8-MariaDB-1:10.4.8+maria~stretch-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ops_type`
--

DROP TABLE IF EXISTS `ops_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ops_type` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `d_count` int(11) NOT NULL,
  `w_count` int(11) NOT NULL,
  `m_count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ops_type`
--

LOCK TABLES `ops_type` WRITE;
/*!40000 ALTER TABLE `ops_type` DISABLE KEYS */;
INSERT INTO `ops_type` VALUES (1,'witness_reward',32268395,-532745,-347525,314377),(2,'witness_update',2837,-242,-238,-136),(3,'account_witness_vote',2414,-213,-236,-145),(4,'withdraw_vesting',5017,-79,-39,159),(5,'account_create',9253,-202,-107,-70),(6,'shutdown_witness',1508,-138,-134,-108),(7,'transfer',113786,-1160,-953,180),(8,'delegate_vesting_shares',15310,-18,22,205),(9,'content',137225,0,0,0),(10,'vote',8959,0,0,0),(11,'chain_properties_update',242,0,0,0),(12,'account_update',5065,-98,-73,-92),(13,'custom',2744821,539065,539461,541388),(14,'committee_worker_create_request',1919,-18,-13,-15),(15,'curation_reward',6554,0,0,0),(16,'author_reward',1498,0,0,0),(17,'content_reward',1498,0,0,0),(18,'content_payout_update',136365,0,0,0),(19,'fill_vesting_withdraw',26011,-59,139,1279),(20,'content_benefactor_reward',1619,0,0,0),(21,'transfer_to_vesting',61284,80,507,2638),(22,'committee_vote_request',1464,-210,-211,-185),(23,'committee_worker_cancel_request',12,0,1,0),(24,'create_invite',1446,-23,2,140),(25,'hardfork',9,0,0,0),(26,'invite_registration',153,-16,-14,-19),(27,'committee_cancel_request',3711,-2,-3,-3),(28,'account_metadata',58859,36,54,70),(29,'set_withdraw_vesting_route',32,-10,-8,-11),(30,'claim_invite_balance',599,-4,18,84),(31,'return_vesting_delegation',11372,-66,17,206),(32,'committee_approve_request',55,-3,-2,-2),(33,'committee_pay_request',59,-2,-1,-1),(34,'committee_payout_request',55,-2,-1,-1),(35,'delete_content',11,0,0,0),(36,'account_witness_proxy',19,0,0,0),(37,'award',1167009,3915,17262,56492),(38,'receive_award',1033458,3757,16211,52987),(39,'versioned_chain_properties_update',400,0,0,0),(40,'benefactor_award',482334,1410,6481,18739),(41,'set_paid_subscription',424,0,0,0),(42,'paid_subscribe',148,0,0,1),(43,'paid_subscription_action',977,0,2,8),(44,'cancel_paid_subscription',107,0,0,1),(45,'set_subaccount_price',32,0,0,0),(46,'set_account_price',833687,-619169,-619151,-619129),(47,'buy_account',36,0,0,0),(48,'account_sale',36,0,0,0),(49,'escrow_transfer',19,0,0,0),(50,'change_recovery_account',5,0,0,0),(51,'proposal_create',10,0,0,0),(52,'proposal_update',7,0,0,0),(53,'escrow_approve',2,0,0,0),(54,'escrow_release',5,0,0,0),(55,'escrow_dispute',1,0,0,0),(56,'use_invite_balance',474,0,5,50),(57,'expire_escrow_ratification',3,0,0,1);
/*!40000 ALTER TABLE `ops_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-25 23:11:31
